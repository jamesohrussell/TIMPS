
float fortran_binary_header;
double lower_obj_index_limit = 10;
double upper_obj_index_limit = 1E100;
double new_id_counter_start = 100000;

long MPI_NUMBER_OF_MAX_ITEMS_SENT_LIMIT = 1000000000;


int number_of_digits_in_input_files=5;
