#!/bin/sh

g++ -O2 -Wall -Wno-unknown-pragmas -Wno-unused-result -o FiT_Object_analysis_basic.exex CC_Object_analysis_FiT_basic.cc -lgd 




