#!/bin/sh

g++ -O2 -Wall -Wno-unknown-pragmas -Wno-unused-result -o FiT_Object_analysis_basic_with_NetCDF4.exex CC_Object_analysis_FiT_basic_with_NetCDF4.cc -I/usr/include/hdf5/serial/ -lgd -lnetcdf 

#g++ -O2 -Wall -Wno-unknown-pragmas -Wno-unused-result -o FiT_Object_analysis_basic_with_NetCDF4.exex CC_Object_analysis_FiT_basic_with_NetCDF4.cc -lgd -lnetcdf_c++ -lnetcdf 





