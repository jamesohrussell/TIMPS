# nclcmaps
NCL colormaps in Python

Usage:

    import nclcmaps
    cmap = nclcmaps.cmap('BlueYellowRed')

See [http://www.ncl.ucar.edu/Document/Graphics/color_table_gallery.shtml](http://www.ncl.ucar.edu/Document/Graphics/color_table_gallery.shtml)
